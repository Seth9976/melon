package androidx.appcompat.app;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

public final class AppLocalesMetadataHolderService extends Service {
    public static final int a;

    @Override  // android.app.Service
    public final IBinder onBind(Intent intent0) {
        throw new UnsupportedOperationException();
    }
}

