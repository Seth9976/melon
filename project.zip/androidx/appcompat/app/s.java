package androidx.appcompat.app;

public final class s implements b {
}

