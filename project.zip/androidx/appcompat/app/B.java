package androidx.appcompat.app;

public interface b {
}

