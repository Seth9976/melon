package androidx.appcompat.app;

public abstract class I {
    public static int a() [...] // Inlined contents
}

