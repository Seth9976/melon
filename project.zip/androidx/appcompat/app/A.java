package androidx.appcompat.app;

import android.content.Context;
import android.view.KeyEvent;
import d5.v;
import j.b;

public abstract class a {
    public boolean a() {
        return false;
    }

    public abstract boolean b();

    public abstract void c(boolean arg1);

    public abstract int d();

    public abstract Context e();

    public abstract void f();

    public boolean g() {
        return false;
    }

    public abstract void h();

    public void i() {
    }

    public abstract boolean j(int arg1, KeyEvent arg2);

    public boolean k(KeyEvent keyEvent0) {
        return false;
    }

    public boolean l() {
        return false;
    }

    public abstract void m(boolean arg1);

    public abstract void n(boolean arg1);

    public abstract void o(int arg1);

    public abstract void p(boolean arg1);

    public abstract void q(String arg1);

    public abstract void r(String arg1);

    public abstract void s(CharSequence arg1);

    public b t(v v0) {
        return null;
    }
}

