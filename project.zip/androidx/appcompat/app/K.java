package androidx.appcompat.app;

import android.os.LocaleList;

public abstract class k {
    public static LocaleList a(String s) {
        return LocaleList.forLanguageTags(s);
    }
}

