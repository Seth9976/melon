package A6;

import com.google.android.material.sidesheet.SideSheetDialog;

public final class j {
    public final SideSheetDialog a;

    public j(SideSheetDialog sideSheetDialog0) {
        this.a = sideSheetDialog0;
    }
}

