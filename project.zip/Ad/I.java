package ad;

import Pc.e;
import ie.H;
import kotlin.jvm.internal.n;
import kotlin.jvm.internal.q;
import we.k;

public final class i extends n implements k {
    @Override  // we.k
    public final Object invoke(Object object0) {
        q.g(((e)object0), "p0");
        ((a)this.receiver).sendUserEvent(((e)object0));
        return H.a;
    }
}

