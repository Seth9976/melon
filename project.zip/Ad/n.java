package ad;

import Yc.D;

public final class n {
    public D a;

}

