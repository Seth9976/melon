package ad;

import Pc.e;

public interface z extends e {
}

