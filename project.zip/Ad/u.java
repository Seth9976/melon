package ad;

public final class u extends w {
    @Override
    public final boolean equals(Object object0) {
        if(this != object0) {
            if(!(object0 instanceof u)) {
                return false;
            }
            ((u)object0).getClass();
        }
        return true;
    }

    @Override
    public final int hashCode() {
        return 0;
    }

    @Override
    public final String toString() {
        return "MelonLogoItem(userEvent=null)";
    }
}

