package ad;

public interface k {
}

