package Af;

import Ue.a;
import Ue.c;
import java.util.Collection;
import java.util.Set;
import qf.e;

public interface p extends r {
    public static final n a;

    static {
        p.a = n.a;
    }

    Set a();

    Collection b(e arg1, c arg2);

    Set d();

    Collection f(e arg1, a arg2);

    Set g();
}

