package Af;

public final class n {
    public static final n a;

    static {
        n.a = new n();  // 初始化器: Ljava/lang/Object;-><init>()V
    }
}

