package Af;

import Me.h;
import Ue.a;
import java.util.Collection;
import qf.e;
import we.k;

public interface r {
    h c(e arg1, a arg2);

    Collection e(f arg1, k arg2);
}

