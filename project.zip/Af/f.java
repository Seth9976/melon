package af;

import ie.m;
import je.D;
import vf.y;
import we.a;

public final class f implements a {
    public static final f a;

    static {
        f.a = new f();  // 初始化器: Ljava/lang/Object;-><init>()V
    }

    @Override  // we.a
    public final Object invoke() {
        y y0 = new y("Deprecated in Java");  // 初始化器: Lvf/g;-><init>(Ljava/lang/Object;)V
        return D.O(new m(c.a, y0));
    }
}

