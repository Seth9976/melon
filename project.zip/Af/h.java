package af;

public final class h {
    public static final h a;
    public static final h b;
    public static final h c;

    static {
        h.a = new h();  // 初始化器: Ljava/lang/Object;-><init>()V
        h.b = new h();  // 初始化器: Ljava/lang/Object;-><init>()V
        h.c = new h();  // 初始化器: Ljava/lang/Object;-><init>()V
    }
}

