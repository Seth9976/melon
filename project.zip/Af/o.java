package Af;

import java.util.Set;
import je.y;

public final class o extends q {
    public static final o b;

    static {
        o.b = new o();  // 初始化器: Ljava/lang/Object;-><init>()V
    }

    @Override  // Af.q
    public final Set a() {
        return y.a;
    }

    @Override  // Af.q
    public final Set d() {
        return y.a;
    }

    @Override  // Af.q
    public final Set g() {
        return y.a;
    }
}

