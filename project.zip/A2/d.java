package a2;

import android.text.Spannable;

public abstract class d implements Spannable {
}

