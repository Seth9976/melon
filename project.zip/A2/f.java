package a2;

import Gf.l;

public abstract class f {
    public static final l a;
    public static final l b;
    public static final l c;
    public static final l d;

    static {
        f.a = new l(null, false);
        f.b = new l(null, true);
        f.c = new l(e.a, false);
        f.d = new l(e.a, true);
    }
}

