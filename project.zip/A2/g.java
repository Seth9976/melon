package A2;

public abstract class g extends h {
}

