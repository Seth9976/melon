package Ac;

import K.m;
import Q0.k0;
import X0.i;
import androidx.compose.runtime.l;
import androidx.compose.runtime.p;
import kotlin.jvm.internal.q;
import w0.h;
import we.k;
import we.o;

public final class l1 implements o {
    public final int a;
    public final k b;

    public l1(int v, k k0) {
        this.a = v;
        this.b = k0;
        super();
    }

    @Override  // we.o
    public final Object invoke(Object object0, Object object1, Object object2) {
        switch(this.a) {
            case 0: {
                ((Number)object2).intValue();
                q.g(((r0.q)object0), "$this$composed");
                ((p)(((l)object1))).a0(0x1FF03545);
                h h1 = (h)((p)(((l)object1))).k(k0.i);
                m m1 = ((p)(((l)object1))).N();
                if(m1 == androidx.compose.runtime.k.a) {
                    m1 = androidx.appcompat.app.o.d(((p)(((l)object1))));
                }
                r0.q q1 = androidx.compose.foundation.q.l(((r0.q)object0), m1, null, true, null, new i(0), new k1(h1, this.b, 0));
                ((p)(((l)object1))).p(false);
                return q1;
            }
            case 1: {
                ((Number)object2).intValue();
                q.g(((r0.q)object0), "$this$composed");
                ((p)(((l)object1))).a0(0x1FF03545);
                h h2 = (h)((p)(((l)object1))).k(k0.i);
                m m2 = ((p)(((l)object1))).N();
                if(m2 == androidx.compose.runtime.k.a) {
                    m2 = androidx.appcompat.app.o.d(((p)(((l)object1))));
                }
                r0.q q2 = androidx.compose.foundation.q.l(((r0.q)object0), m2, null, true, null, new i(0), new k1(h2, this.b, 1));
                ((p)(((l)object1))).p(false);
                return q2;
            }
            case 2: {
                ((Number)object2).intValue();
                q.g(((r0.q)object0), "$this$composed");
                ((p)(((l)object1))).a0(0x1FF03545);
                h h3 = (h)((p)(((l)object1))).k(k0.i);
                m m3 = ((p)(((l)object1))).N();
                if(m3 == androidx.compose.runtime.k.a) {
                    m3 = androidx.appcompat.app.o.d(((p)(((l)object1))));
                }
                r0.q q3 = androidx.compose.foundation.q.l(((r0.q)object0), m3, null, true, null, new i(0), new k1(h3, this.b, 2));
                ((p)(((l)object1))).p(false);
                return q3;
            }
            case 3: {
                ((Number)object2).intValue();
                q.g(((r0.q)object0), "$this$composed");
                ((p)(((l)object1))).a0(0x1FF03545);
                h h4 = (h)((p)(((l)object1))).k(k0.i);
                m m4 = ((p)(((l)object1))).N();
                if(m4 == androidx.compose.runtime.k.a) {
                    m4 = androidx.appcompat.app.o.d(((p)(((l)object1))));
                }
                r0.q q4 = androidx.compose.foundation.q.l(((r0.q)object0), m4, null, true, null, new i(0), new k1(h4, this.b, 3));
                ((p)(((l)object1))).p(false);
                return q4;
            }
            case 4: {
                ((Number)object2).intValue();
                q.g(((r0.q)object0), "$this$composed");
                ((p)(((l)object1))).a0(0x1FF03545);
                h h5 = (h)((p)(((l)object1))).k(k0.i);
                m m5 = ((p)(((l)object1))).N();
                if(m5 == androidx.compose.runtime.k.a) {
                    m5 = androidx.appcompat.app.o.d(((p)(((l)object1))));
                }
                r0.q q5 = androidx.compose.foundation.q.l(((r0.q)object0), m5, null, true, null, new i(0), new k1(h5, this.b, 4));
                ((p)(((l)object1))).p(false);
                return q5;
            }
            case 5: {
                ((Number)object2).intValue();
                q.g(((r0.q)object0), "$this$composed");
                ((p)(((l)object1))).a0(0x1FF03545);
                h h6 = (h)((p)(((l)object1))).k(k0.i);
                m m6 = ((p)(((l)object1))).N();
                if(m6 == androidx.compose.runtime.k.a) {
                    m6 = androidx.appcompat.app.o.d(((p)(((l)object1))));
                }
                r0.q q6 = androidx.compose.foundation.q.l(((r0.q)object0), m6, null, true, null, new i(0), new k1(h6, this.b, 5));
                ((p)(((l)object1))).p(false);
                return q6;
            }
            case 6: {
                ((Number)object2).intValue();
                q.g(((r0.q)object0), "$this$composed");
                ((p)(((l)object1))).a0(0x1FF03545);
                h h7 = (h)((p)(((l)object1))).k(k0.i);
                m m7 = ((p)(((l)object1))).N();
                if(m7 == androidx.compose.runtime.k.a) {
                    m7 = androidx.appcompat.app.o.d(((p)(((l)object1))));
                }
                r0.q q7 = androidx.compose.foundation.q.l(((r0.q)object0), m7, null, true, null, new i(0), new k1(h7, this.b, 6));
                ((p)(((l)object1))).p(false);
                return q7;
            }
            case 7: {
                ((Number)object2).intValue();
                q.g(((r0.q)object0), "$this$composed");
                ((p)(((l)object1))).a0(0x1FF03545);
                h h8 = (h)((p)(((l)object1))).k(k0.i);
                m m8 = ((p)(((l)object1))).N();
                if(m8 == androidx.compose.runtime.k.a) {
                    m8 = androidx.appcompat.app.o.d(((p)(((l)object1))));
                }
                r0.q q8 = androidx.compose.foundation.q.l(((r0.q)object0), m8, null, true, null, new i(0), new k1(h8, this.b, 7));
                ((p)(((l)object1))).p(false);
                return q8;
            }
            case 8: {
                ((Number)object2).intValue();
                q.g(((r0.q)object0), "$this$composed");
                ((p)(((l)object1))).a0(0x1FF03545);
                h h9 = (h)((p)(((l)object1))).k(k0.i);
                m m9 = ((p)(((l)object1))).N();
                if(m9 == androidx.compose.runtime.k.a) {
                    m9 = androidx.appcompat.app.o.d(((p)(((l)object1))));
                }
                r0.q q9 = androidx.compose.foundation.q.l(((r0.q)object0), m9, null, true, null, new i(0), new k1(h9, this.b, 8));
                ((p)(((l)object1))).p(false);
                return q9;
            }
            case 9: {
                ((Number)object2).intValue();
                q.g(((r0.q)object0), "$this$composed");
                ((p)(((l)object1))).a0(0x1FF03545);
                h h10 = (h)((p)(((l)object1))).k(k0.i);
                m m10 = ((p)(((l)object1))).N();
                if(m10 == androidx.compose.runtime.k.a) {
                    m10 = androidx.appcompat.app.o.d(((p)(((l)object1))));
                }
                r0.q q10 = androidx.compose.foundation.q.l(((r0.q)object0), m10, null, true, null, new i(0), new k1(h10, this.b, 9));
                ((p)(((l)object1))).p(false);
                return q10;
            }
            case 10: {
                ((Number)object2).intValue();
                q.g(((r0.q)object0), "$this$composed");
                ((p)(((l)object1))).a0(0x1FF03545);
                h h11 = (h)((p)(((l)object1))).k(k0.i);
                m m11 = ((p)(((l)object1))).N();
                if(m11 == androidx.compose.runtime.k.a) {
                    m11 = androidx.appcompat.app.o.d(((p)(((l)object1))));
                }
                r0.q q11 = androidx.compose.foundation.q.l(((r0.q)object0), m11, null, true, null, new i(0), new k1(h11, this.b, 10));
                ((p)(((l)object1))).p(false);
                return q11;
            }
            case 11: {
                ((Number)object2).intValue();
                q.g(((r0.q)object0), "$this$composed");
                ((p)(((l)object1))).a0(0x1FF03545);
                h h12 = (h)((p)(((l)object1))).k(k0.i);
                m m12 = ((p)(((l)object1))).N();
                if(m12 == androidx.compose.runtime.k.a) {
                    m12 = androidx.appcompat.app.o.d(((p)(((l)object1))));
                }
                r0.q q12 = androidx.compose.foundation.q.l(((r0.q)object0), m12, null, true, null, new i(0), new k1(h12, this.b, 11));
                ((p)(((l)object1))).p(false);
                return q12;
            }
            case 12: {
                ((Number)object2).intValue();
                q.g(((r0.q)object0), "$this$composed");
                ((p)(((l)object1))).a0(0x1FF03545);
                h h13 = (h)((p)(((l)object1))).k(k0.i);
                m m13 = ((p)(((l)object1))).N();
                if(m13 == androidx.compose.runtime.k.a) {
                    m13 = androidx.appcompat.app.o.d(((p)(((l)object1))));
                }
                r0.q q13 = androidx.compose.foundation.q.l(((r0.q)object0), m13, null, true, null, new i(0), new k1(h13, this.b, 12));
                ((p)(((l)object1))).p(false);
                return q13;
            }
            case 13: {
                ((Number)object2).intValue();
                q.g(((r0.q)object0), "$this$composed");
                ((p)(((l)object1))).a0(0x1FF03545);
                h h14 = (h)((p)(((l)object1))).k(k0.i);
                m m14 = ((p)(((l)object1))).N();
                if(m14 == androidx.compose.runtime.k.a) {
                    m14 = androidx.appcompat.app.o.d(((p)(((l)object1))));
                }
                r0.q q14 = androidx.compose.foundation.q.l(((r0.q)object0), m14, null, true, null, new i(0), new k1(h14, this.b, 13));
                ((p)(((l)object1))).p(false);
                return q14;
            }
            case 14: {
                ((Number)object2).intValue();
                q.g(((r0.q)object0), "$this$composed");
                ((p)(((l)object1))).a0(0x1FF03545);
                h h15 = (h)((p)(((l)object1))).k(k0.i);
                m m15 = ((p)(((l)object1))).N();
                if(m15 == androidx.compose.runtime.k.a) {
                    m15 = androidx.appcompat.app.o.d(((p)(((l)object1))));
                }
                r0.q q15 = androidx.compose.foundation.q.l(((r0.q)object0), m15, null, true, null, new i(0), new k1(h15, this.b, 14));
                ((p)(((l)object1))).p(false);
                return q15;
            }
            case 15: {
                ((Number)object2).intValue();
                q.g(((r0.q)object0), "$this$composed");
                ((p)(((l)object1))).a0(0x1FF03545);
                h h16 = (h)((p)(((l)object1))).k(k0.i);
                m m16 = ((p)(((l)object1))).N();
                if(m16 == androidx.compose.runtime.k.a) {
                    m16 = androidx.appcompat.app.o.d(((p)(((l)object1))));
                }
                r0.q q16 = androidx.compose.foundation.q.l(((r0.q)object0), m16, null, true, null, new i(0), new k1(h16, this.b, 15));
                ((p)(((l)object1))).p(false);
                return q16;
            }
            case 16: {
                ((Number)object2).intValue();
                q.g(((r0.q)object0), "$this$composed");
                ((p)(((l)object1))).a0(0x1FF03545);
                h h17 = (h)((p)(((l)object1))).k(k0.i);
                m m17 = ((p)(((l)object1))).N();
                if(m17 == androidx.compose.runtime.k.a) {
                    m17 = androidx.appcompat.app.o.d(((p)(((l)object1))));
                }
                r0.q q17 = androidx.compose.foundation.q.l(((r0.q)object0), m17, null, true, null, new i(0), new k1(h17, this.b, 16));
                ((p)(((l)object1))).p(false);
                return q17;
            }
            case 17: {
                ((Number)object2).intValue();
                q.g(((r0.q)object0), "$this$composed");
                ((p)(((l)object1))).a0(0x1FF03545);
                h h18 = (h)((p)(((l)object1))).k(k0.i);
                m m18 = ((p)(((l)object1))).N();
                if(m18 == androidx.compose.runtime.k.a) {
                    m18 = androidx.appcompat.app.o.d(((p)(((l)object1))));
                }
                r0.q q18 = androidx.compose.foundation.q.l(((r0.q)object0), m18, null, true, null, new i(0), new k1(h18, this.b, 17));
                ((p)(((l)object1))).p(false);
                return q18;
            }
            case 18: {
                ((Number)object2).intValue();
                q.g(((r0.q)object0), "$this$composed");
                ((p)(((l)object1))).a0(0x1FF03545);
                h h19 = (h)((p)(((l)object1))).k(k0.i);
                m m19 = ((p)(((l)object1))).N();
                if(m19 == androidx.compose.runtime.k.a) {
                    m19 = androidx.appcompat.app.o.d(((p)(((l)object1))));
                }
                r0.q q19 = androidx.compose.foundation.q.l(((r0.q)object0), m19, null, true, null, new i(0), new k1(h19, this.b, 18));
                ((p)(((l)object1))).p(false);
                return q19;
            }
            case 19: {
                ((Number)object2).intValue();
                q.g(((r0.q)object0), "$this$composed");
                ((p)(((l)object1))).a0(0x1FF03545);
                h h20 = (h)((p)(((l)object1))).k(k0.i);
                m m20 = ((p)(((l)object1))).N();
                if(m20 == androidx.compose.runtime.k.a) {
                    m20 = androidx.appcompat.app.o.d(((p)(((l)object1))));
                }
                r0.q q20 = androidx.compose.foundation.q.l(((r0.q)object0), m20, null, true, null, new i(0), new k1(h20, this.b, 19));
                ((p)(((l)object1))).p(false);
                return q20;
            }
            case 20: {
                ((Number)object2).intValue();
                q.g(((r0.q)object0), "$this$composed");
                ((p)(((l)object1))).a0(0x1FF03545);
                h h21 = (h)((p)(((l)object1))).k(k0.i);
                m m21 = ((p)(((l)object1))).N();
                if(m21 == androidx.compose.runtime.k.a) {
                    m21 = androidx.appcompat.app.o.d(((p)(((l)object1))));
                }
                r0.q q21 = androidx.compose.foundation.q.l(((r0.q)object0), m21, null, true, null, new i(0), new k1(h21, this.b, 20));
                ((p)(((l)object1))).p(false);
                return q21;
            }
            case 21: {
                ((Number)object2).intValue();
                q.g(((r0.q)object0), "$this$composed");
                ((p)(((l)object1))).a0(0x1FF03545);
                h h22 = (h)((p)(((l)object1))).k(k0.i);
                m m22 = ((p)(((l)object1))).N();
                if(m22 == androidx.compose.runtime.k.a) {
                    m22 = androidx.appcompat.app.o.d(((p)(((l)object1))));
                }
                r0.q q22 = androidx.compose.foundation.q.l(((r0.q)object0), m22, null, true, null, new i(0), new k1(h22, this.b, 21));
                ((p)(((l)object1))).p(false);
                return q22;
            }
            case 22: {
                ((Number)object2).intValue();
                q.g(((r0.q)object0), "$this$composed");
                ((p)(((l)object1))).a0(0x1FF03545);
                h h23 = (h)((p)(((l)object1))).k(k0.i);
                m m23 = ((p)(((l)object1))).N();
                if(m23 == androidx.compose.runtime.k.a) {
                    m23 = androidx.appcompat.app.o.d(((p)(((l)object1))));
                }
                r0.q q23 = androidx.compose.foundation.q.l(((r0.q)object0), m23, null, true, null, new i(0), new k1(h23, this.b, 22));
                ((p)(((l)object1))).p(false);
                return q23;
            }
            case 23: {
                ((Number)object2).intValue();
                q.g(((r0.q)object0), "$this$composed");
                ((p)(((l)object1))).a0(0x1FF03545);
                h h24 = (h)((p)(((l)object1))).k(k0.i);
                m m24 = ((p)(((l)object1))).N();
                if(m24 == androidx.compose.runtime.k.a) {
                    m24 = androidx.appcompat.app.o.d(((p)(((l)object1))));
                }
                r0.q q24 = androidx.compose.foundation.q.l(((r0.q)object0), m24, null, true, null, new i(0), new k1(h24, this.b, 23));
                ((p)(((l)object1))).p(false);
                return q24;
            }
            case 24: {
                ((Number)object2).intValue();
                q.g(((r0.q)object0), "$this$composed");
                ((p)(((l)object1))).a0(0x1FF03545);
                h h25 = (h)((p)(((l)object1))).k(k0.i);
                m m25 = ((p)(((l)object1))).N();
                if(m25 == androidx.compose.runtime.k.a) {
                    m25 = androidx.appcompat.app.o.d(((p)(((l)object1))));
                }
                r0.q q25 = androidx.compose.foundation.q.l(((r0.q)object0), m25, null, true, null, new i(0), new k1(h25, this.b, 24));
                ((p)(((l)object1))).p(false);
                return q25;
            }
            case 25: {
                ((Number)object2).intValue();
                q.g(((r0.q)object0), "$this$composed");
                ((p)(((l)object1))).a0(0x1FF03545);
                h h26 = (h)((p)(((l)object1))).k(k0.i);
                m m26 = ((p)(((l)object1))).N();
                if(m26 == androidx.compose.runtime.k.a) {
                    m26 = androidx.appcompat.app.o.d(((p)(((l)object1))));
                }
                r0.q q26 = androidx.compose.foundation.q.l(((r0.q)object0), m26, null, true, null, new i(0), new k1(h26, this.b, 25));
                ((p)(((l)object1))).p(false);
                return q26;
            }
            case 26: {
                ((Number)object2).intValue();
                q.g(((r0.q)object0), "$this$composed");
                ((p)(((l)object1))).a0(0x1FF03545);
                h h27 = (h)((p)(((l)object1))).k(k0.i);
                m m27 = ((p)(((l)object1))).N();
                if(m27 == androidx.compose.runtime.k.a) {
                    m27 = androidx.appcompat.app.o.d(((p)(((l)object1))));
                }
                r0.q q27 = androidx.compose.foundation.q.l(((r0.q)object0), m27, null, true, null, new i(0), new k1(h27, this.b, 26));
                ((p)(((l)object1))).p(false);
                return q27;
            }
            case 27: {
                ((Number)object2).intValue();
                q.g(((r0.q)object0), "$this$composed");
                ((p)(((l)object1))).a0(0x1FF03545);
                h h28 = (h)((p)(((l)object1))).k(k0.i);
                m m28 = ((p)(((l)object1))).N();
                if(m28 == androidx.compose.runtime.k.a) {
                    m28 = androidx.appcompat.app.o.d(((p)(((l)object1))));
                }
                r0.q q28 = androidx.compose.foundation.q.l(((r0.q)object0), m28, null, true, null, new i(0), new k1(h28, this.b, 27));
                ((p)(((l)object1))).p(false);
                return q28;
            }
            case 28: {
                ((Number)object2).intValue();
                q.g(((r0.q)object0), "$this$composed");
                ((p)(((l)object1))).a0(0x1FF03545);
                h h29 = (h)((p)(((l)object1))).k(k0.i);
                m m29 = ((p)(((l)object1))).N();
                if(m29 == androidx.compose.runtime.k.a) {
                    m29 = androidx.appcompat.app.o.d(((p)(((l)object1))));
                }
                r0.q q29 = androidx.compose.foundation.q.l(((r0.q)object0), m29, null, true, null, new i(0), new k1(h29, this.b, 28));
                ((p)(((l)object1))).p(false);
                return q29;
            }
            default: {
                ((Number)object2).intValue();
                q.g(((r0.q)object0), "$this$composed");
                ((p)(((l)object1))).a0(0x1FF03545);
                h h0 = (h)((p)(((l)object1))).k(k0.i);
                m m0 = ((p)(((l)object1))).N();
                if(m0 == androidx.compose.runtime.k.a) {
                    m0 = androidx.appcompat.app.o.d(((p)(((l)object1))));
                }
                r0.q q0 = androidx.compose.foundation.q.l(((r0.q)object0), m0, null, true, null, new i(0), new k1(h0, this.b, 29));
                ((p)(((l)object1))).p(false);
                return q0;
            }
        }
    }
}

