package Ac;

import Pc.e;

public final class w3 implements e {
    public static final w3 a;

    static {
        w3.a = new w3();  // 初始化器: Ljava/lang/Object;-><init>()V
    }

    // 去混淆评级： 低(20)
    @Override
    public final boolean equals(Object object0) {
        return this == object0 ? true : object0 instanceof w3;
    }

    @Override
    public final int hashCode() {
        return -731779403;
    }

    @Override
    public final String toString() {
        return "Refresh";
    }
}

