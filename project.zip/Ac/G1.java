package Ac;

import N0.M;
import N0.N;
import N0.O;
import androidx.compose.runtime.b0;
import java.util.LinkedHashMap;
import java.util.List;
import je.x;
import x1.m;
import x1.q;

public final class g1 implements M {
    public final int a;
    public final b0 b;
    public final q c;
    public final m d;
    public final b0 e;

    public g1(b0 b00, q q0, m m0, int v, b0 b01) {
        this.a = v;
        this.b = b00;
        this.c = q0;
        this.d = m0;
        this.e = b01;
        super();
    }

    @Override  // N0.M
    public final N measure-3p2s80s(O o0, List list0, long v) {
        switch(this.a) {
            case 0: {
                LinkedHashMap linkedHashMap1 = new LinkedHashMap();
                this.b.getValue();
                r1.m m1 = o0.getLayoutDirection();
                long v2 = this.c.f(v, m1, this.d, list0, linkedHashMap1, 0x101);
                this.e.getValue();
                f1 f11 = new f1(this.c, list0, linkedHashMap1, 0);
                return o0.w(((int)(v2 >> 0x20)), ((int)(v2 & 0xFFFFFFFFL)), x.a, f11);
            }
            case 1: {
                LinkedHashMap linkedHashMap2 = new LinkedHashMap();
                this.b.getValue();
                r1.m m2 = o0.getLayoutDirection();
                long v3 = this.c.f(v, m2, this.d, list0, linkedHashMap2, 0x101);
                this.e.getValue();
                f1 f12 = new f1(this.c, list0, linkedHashMap2, 1);
                return o0.w(((int)(v3 >> 0x20)), ((int)(v3 & 0xFFFFFFFFL)), x.a, f12);
            }
            case 2: {
                LinkedHashMap linkedHashMap3 = new LinkedHashMap();
                this.b.getValue();
                r1.m m3 = o0.getLayoutDirection();
                long v4 = this.c.f(v, m3, this.d, list0, linkedHashMap3, 0x101);
                this.e.getValue();
                f1 f13 = new f1(this.c, list0, linkedHashMap3, 2);
                return o0.w(((int)(v4 >> 0x20)), ((int)(v4 & 0xFFFFFFFFL)), x.a, f13);
            }
            case 3: {
                LinkedHashMap linkedHashMap4 = new LinkedHashMap();
                this.b.getValue();
                r1.m m4 = o0.getLayoutDirection();
                long v5 = this.c.f(v, m4, this.d, list0, linkedHashMap4, 0x101);
                this.e.getValue();
                f1 f14 = new f1(this.c, list0, linkedHashMap4, 3);
                return o0.w(((int)(v5 >> 0x20)), ((int)(v5 & 0xFFFFFFFFL)), x.a, f14);
            }
            case 4: {
                LinkedHashMap linkedHashMap5 = new LinkedHashMap();
                this.b.getValue();
                r1.m m5 = o0.getLayoutDirection();
                long v6 = this.c.f(v, m5, this.d, list0, linkedHashMap5, 0x101);
                this.e.getValue();
                f1 f15 = new f1(this.c, list0, linkedHashMap5, 4);
                return o0.w(((int)(v6 >> 0x20)), ((int)(v6 & 0xFFFFFFFFL)), x.a, f15);
            }
            case 5: {
                LinkedHashMap linkedHashMap6 = new LinkedHashMap();
                this.b.getValue();
                r1.m m6 = o0.getLayoutDirection();
                long v7 = this.c.f(v, m6, this.d, list0, linkedHashMap6, 0x101);
                this.e.getValue();
                f1 f16 = new f1(this.c, list0, linkedHashMap6, 5);
                return o0.w(((int)(v7 >> 0x20)), ((int)(v7 & 0xFFFFFFFFL)), x.a, f16);
            }
            case 6: {
                LinkedHashMap linkedHashMap7 = new LinkedHashMap();
                this.b.getValue();
                r1.m m7 = o0.getLayoutDirection();
                long v8 = this.c.f(v, m7, this.d, list0, linkedHashMap7, 0x101);
                this.e.getValue();
                f1 f17 = new f1(this.c, list0, linkedHashMap7, 6);
                return o0.w(((int)(v8 >> 0x20)), ((int)(v8 & 0xFFFFFFFFL)), x.a, f17);
            }
            case 7: {
                LinkedHashMap linkedHashMap8 = new LinkedHashMap();
                this.b.getValue();
                r1.m m8 = o0.getLayoutDirection();
                long v9 = this.c.f(v, m8, this.d, list0, linkedHashMap8, 0x101);
                this.e.getValue();
                f1 f18 = new f1(this.c, list0, linkedHashMap8, 7);
                return o0.w(((int)(v9 >> 0x20)), ((int)(v9 & 0xFFFFFFFFL)), x.a, f18);
            }
            case 8: {
                LinkedHashMap linkedHashMap9 = new LinkedHashMap();
                this.b.getValue();
                r1.m m9 = o0.getLayoutDirection();
                long v10 = this.c.f(v, m9, this.d, list0, linkedHashMap9, 0x101);
                this.e.getValue();
                f1 f19 = new f1(this.c, list0, linkedHashMap9, 8);
                return o0.w(((int)(v10 >> 0x20)), ((int)(v10 & 0xFFFFFFFFL)), x.a, f19);
            }
            case 9: {
                LinkedHashMap linkedHashMap10 = new LinkedHashMap();
                this.b.getValue();
                r1.m m10 = o0.getLayoutDirection();
                long v11 = this.c.f(v, m10, this.d, list0, linkedHashMap10, 0x101);
                this.e.getValue();
                f1 f110 = new f1(this.c, list0, linkedHashMap10, 9);
                return o0.w(((int)(v11 >> 0x20)), ((int)(v11 & 0xFFFFFFFFL)), x.a, f110);
            }
            case 10: {
                LinkedHashMap linkedHashMap11 = new LinkedHashMap();
                this.b.getValue();
                r1.m m11 = o0.getLayoutDirection();
                long v12 = this.c.f(v, m11, this.d, list0, linkedHashMap11, 0x101);
                this.e.getValue();
                f1 f111 = new f1(this.c, list0, linkedHashMap11, 10);
                return o0.w(((int)(v12 >> 0x20)), ((int)(v12 & 0xFFFFFFFFL)), x.a, f111);
            }
            case 11: {
                LinkedHashMap linkedHashMap12 = new LinkedHashMap();
                this.b.getValue();
                r1.m m12 = o0.getLayoutDirection();
                long v13 = this.c.f(v, m12, this.d, list0, linkedHashMap12, 0x101);
                this.e.getValue();
                f1 f112 = new f1(this.c, list0, linkedHashMap12, 11);
                return o0.w(((int)(v13 >> 0x20)), ((int)(v13 & 0xFFFFFFFFL)), x.a, f112);
            }
            case 12: {
                LinkedHashMap linkedHashMap13 = new LinkedHashMap();
                this.b.getValue();
                r1.m m13 = o0.getLayoutDirection();
                long v14 = this.c.f(v, m13, this.d, list0, linkedHashMap13, 0x101);
                this.e.getValue();
                f1 f113 = new f1(this.c, list0, linkedHashMap13, 12);
                return o0.w(((int)(v14 >> 0x20)), ((int)(v14 & 0xFFFFFFFFL)), x.a, f113);
            }
            case 13: {
                LinkedHashMap linkedHashMap14 = new LinkedHashMap();
                this.b.getValue();
                r1.m m14 = o0.getLayoutDirection();
                long v15 = this.c.f(v, m14, this.d, list0, linkedHashMap14, 0x101);
                this.e.getValue();
                f1 f114 = new f1(this.c, list0, linkedHashMap14, 13);
                return o0.w(((int)(v15 >> 0x20)), ((int)(v15 & 0xFFFFFFFFL)), x.a, f114);
            }
            case 14: {
                LinkedHashMap linkedHashMap15 = new LinkedHashMap();
                this.b.getValue();
                r1.m m15 = o0.getLayoutDirection();
                long v16 = this.c.f(v, m15, this.d, list0, linkedHashMap15, 0x101);
                this.e.getValue();
                f1 f115 = new f1(this.c, list0, linkedHashMap15, 14);
                return o0.w(((int)(v16 >> 0x20)), ((int)(v16 & 0xFFFFFFFFL)), x.a, f115);
            }
            case 15: {
                LinkedHashMap linkedHashMap16 = new LinkedHashMap();
                this.b.getValue();
                r1.m m16 = o0.getLayoutDirection();
                long v17 = this.c.f(v, m16, this.d, list0, linkedHashMap16, 0x101);
                this.e.getValue();
                f1 f116 = new f1(this.c, list0, linkedHashMap16, 15);
                return o0.w(((int)(v17 >> 0x20)), ((int)(v17 & 0xFFFFFFFFL)), x.a, f116);
            }
            case 16: {
                LinkedHashMap linkedHashMap17 = new LinkedHashMap();
                this.b.getValue();
                r1.m m17 = o0.getLayoutDirection();
                long v18 = this.c.f(v, m17, this.d, list0, linkedHashMap17, 0x101);
                this.e.getValue();
                f1 f117 = new f1(this.c, list0, linkedHashMap17, 16);
                return o0.w(((int)(v18 >> 0x20)), ((int)(v18 & 0xFFFFFFFFL)), x.a, f117);
            }
            case 17: {
                LinkedHashMap linkedHashMap18 = new LinkedHashMap();
                this.b.getValue();
                r1.m m18 = o0.getLayoutDirection();
                long v19 = this.c.f(v, m18, this.d, list0, linkedHashMap18, 0x101);
                this.e.getValue();
                f1 f118 = new f1(this.c, list0, linkedHashMap18, 17);
                return o0.w(((int)(v19 >> 0x20)), ((int)(v19 & 0xFFFFFFFFL)), x.a, f118);
            }
            case 18: {
                LinkedHashMap linkedHashMap19 = new LinkedHashMap();
                this.b.getValue();
                r1.m m19 = o0.getLayoutDirection();
                long v20 = this.c.f(v, m19, this.d, list0, linkedHashMap19, 0x101);
                this.e.getValue();
                f1 f119 = new f1(this.c, list0, linkedHashMap19, 18);
                return o0.w(((int)(v20 >> 0x20)), ((int)(v20 & 0xFFFFFFFFL)), x.a, f119);
            }
            default: {
                LinkedHashMap linkedHashMap0 = new LinkedHashMap();
                this.b.getValue();
                r1.m m0 = o0.getLayoutDirection();
                long v1 = this.c.f(v, m0, this.d, list0, linkedHashMap0, 0x101);
                this.e.getValue();
                f1 f10 = new f1(this.c, list0, linkedHashMap0, 19);
                return o0.w(((int)(v1 >> 0x20)), ((int)(v1 & 0xFFFFFFFFL)), x.a, f10);
            }
        }
    }
}

