package Ac;

public interface k3 {
}

