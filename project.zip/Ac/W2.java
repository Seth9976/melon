package Ac;

public interface w2 {
}

