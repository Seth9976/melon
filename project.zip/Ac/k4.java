package Ac;

import kotlin.jvm.internal.q;

public final class k4 extends m4 {
    public final String a;

    public k4(String s) {
        this.a = s;
    }

    @Override
    public final boolean equals(Object object0) {
        if(this == object0) {
            return true;
        }
        return object0 instanceof k4 ? q.b(this.a, ((k4)object0).a) : false;
    }

    @Override
    public final int hashCode() {
        return this.a.hashCode();
    }

    @Override
    public final String toString() {
        return "Error(message=" + this.a + ")";
    }
}

