package Ac;

import kotlin.jvm.internal.q;
import pe.b;

public enum o4 {
    WRITE,
    EDIT;

    public static final o4[] c;

    static {
        o4.c = arr_o4;
        q.g(arr_o4, "entries");
        new b(arr_o4);
    }
}

