package Ac;

import Dd.F0;
import Dd.G0;
import Dd.H0;
import Dd.I0;
import Dd.K0;
import Rc.P;
import Rc.Q;
import Rc.S;
import Rc.T;
import Rc.X;
import Rc.Y;
import Rc.c0;
import Yc.o;
import Yc.q;
import Yc.t;
import Yc.w;
import gd.G5;
import gd.p8;
import gd.r8;
import gd.s8;
import gd.z5;
import ie.H;
import jd.m1;
import w0.h;
import we.a;
import we.k;

public final class k1 implements a {
    public final int a;
    public final h b;
    public final k c;

    public k1(h h0, k k0, int v) {
        this.a = v;
        this.b = h0;
        this.c = k0;
        super();
    }

    @Override  // we.a
    public final Object invoke() {
        switch(this.a) {
            case 0: {
                h.a(this.b);
                this.c.invoke(X1.a);
                return H.a;
            }
            case 1: {
                h.a(this.b);
                this.c.invoke(I0.a);
                return H.a;
            }
            case 2: {
                h.a(this.b);
                H0 h00 = new H0();  // 初始化器: Ljava/lang/Object;-><init>()V
                this.c.invoke(h00);
                return H.a;
            }
            case 3: {
                h.a(this.b);
                F0 f00 = new F0();  // 初始化器: Ljava/lang/Object;-><init>()V
                this.c.invoke(f00);
                return H.a;
            }
            case 4: {
                h.a(this.b);
                G0 g00 = new G0();  // 初始化器: Ljava/lang/Object;-><init>()V
                this.c.invoke(g00);
                return H.a;
            }
            case 5: {
                h.a(this.b);
                this.c.invoke(K0.a);
                return H.a;
            }
            case 6: {
                h.a(this.b);
                this.c.invoke(S.a);
                return H.a;
            }
            case 7: {
                h.a(this.b);
                this.c.invoke(S.a);
                return H.a;
            }
            case 8: {
                h.a(this.b);
                this.c.invoke(c0.a);
                return H.a;
            }
            case 9: {
                h.a(this.b);
                this.c.invoke(Q.a);
                return H.a;
            }
            case 10: {
                h.a(this.b);
                this.c.invoke(S.a);
                return H.a;
            }
            case 11: {
                h.a(this.b);
                this.c.invoke(T.a);
                return H.a;
            }
            case 12: {
                h.a(this.b);
                this.c.invoke(X.a);
                return H.a;
            }
            case 13: {
                h.a(this.b);
                this.c.invoke(Y.a);
                return H.a;
            }
            case 14: {
                h.a(this.b);
                this.c.invoke(P.a);
                return H.a;
            }
            case 15: {
                h.a(this.b);
                this.c.invoke(P.a);
                return H.a;
            }
            case 16: {
                h.a(this.b);
                t t0 = new t(false);
                this.c.invoke(t0);
                return H.a;
            }
            case 17: {
                h.a(this.b);
                this.c.invoke(w.a);
                return H.a;
            }
            case 18: {
                h.a(this.b);
                this.c.invoke(o.a);
                return H.a;
            }
            case 19: {
                h.a(this.b);
                t t1 = new t(true);
                this.c.invoke(t1);
                return H.a;
            }
            case 20: {
                h.a(this.b);
                this.c.invoke(q.a);
                return H.a;
            }
            case 21: {
                h.a(this.b);
                this.c.invoke(cd.a.c);
                return H.a;
            }
            case 22: {
                h.a(this.b);
                this.c.invoke(cd.a.d);
                return H.a;
            }
            case 23: {
                h.a(this.b);
                this.c.invoke(cd.a.e);
                return H.a;
            }
            case 24: {
                h.a(this.b);
                k k0 = this.c;
                if(k0 != null) {
                    k0.invoke(G5.a);
                }
                return H.a;
            }
            case 25: {
                h.a(this.b);
                k k1 = this.c;
                if(k1 != null) {
                    k1.invoke(z5.a);
                }
                return H.a;
            }
            case 26: {
                h.a(this.b);
                this.c.invoke(p8.a);
                return H.a;
            }
            case 27: {
                h.a(this.b);
                this.c.invoke(s8.a);
                return H.a;
            }
            case 28: {
                h.a(this.b);
                this.c.invoke(r8.a);
                return H.a;
            }
            default: {
                h.a(this.b);
                this.c.invoke(m1.a);
                return H.a;
            }
        }
    }
}

