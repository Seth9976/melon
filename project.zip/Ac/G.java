package ac;

import H0.e;

public final class g extends e {
    public static final g e;

    static {
        g.e = new g();  // 初始化器: Ljava/lang/Object;-><init>()V
    }

    // 去混淆评级： 低(20)
    @Override
    public final boolean equals(Object object0) {
        return this == object0 ? true : object0 instanceof g;
    }

    @Override
    public final int hashCode() {
        return 0x92CD1D50;
    }

    @Override
    public final String toString() {
        return "None";
    }
}

