package Ac;

import com.melon.ui.K4;

public abstract class m4 implements K4 {
}

