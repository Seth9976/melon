package Ac;

import Md.i;

public final class y4 implements i {
    public static final y4 a;

    static {
        y4.a = new y4();  // 初始化器: Ljava/lang/Object;-><init>()V
    }
}

