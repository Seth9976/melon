package Ac;

import E9.g;
import W.p;
import ie.H;
import kotlin.jvm.internal.q;
import we.k;
import x1.d;

public final class d1 implements k {
    public static final d1 a;

    static {
        d1.a = new d1();  // 初始化器: Ljava/lang/Object;-><init>()V
    }

    @Override  // we.k
    public final Object invoke(Object object0) {
        q.g(((d)object0), "$this$constrainAs");
        p.l(((d)object0).f, ((d)object0).c.f, 0.0f, 6);
        g.v(((d)object0).e, ((d)object0).c.e, 0.0f, 6);
        g.v(((d)object0).g, ((d)object0).c.g, 0.0f, 6);
        return H.a;
    }
}

