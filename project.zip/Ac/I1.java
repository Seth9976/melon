package Ac;

import X0.x;
import ie.H;
import kotlin.jvm.internal.r;
import we.k;
import x1.q;
import x1.t;

public final class i1 extends r implements k {
    public final int f;
    public final q g;

    public i1(q q0, int v) {
        this.f = v;
        this.g = q0;
        super(1);
    }

    @Override  // we.k
    public final Object invoke(Object object0) {
        switch(this.f) {
            case 0: {
                t.a(((x)object0), this.g);
                return H.a;
            }
            case 1: {
                t.a(((x)object0), this.g);
                return H.a;
            }
            case 2: {
                t.a(((x)object0), this.g);
                return H.a;
            }
            case 3: {
                t.a(((x)object0), this.g);
                return H.a;
            }
            case 4: {
                t.a(((x)object0), this.g);
                return H.a;
            }
            case 5: {
                t.a(((x)object0), this.g);
                return H.a;
            }
            case 6: {
                t.a(((x)object0), this.g);
                return H.a;
            }
            case 7: {
                t.a(((x)object0), this.g);
                return H.a;
            }
            case 8: {
                t.a(((x)object0), this.g);
                return H.a;
            }
            case 9: {
                t.a(((x)object0), this.g);
                return H.a;
            }
            case 10: {
                t.a(((x)object0), this.g);
                return H.a;
            }
            case 11: {
                t.a(((x)object0), this.g);
                return H.a;
            }
            case 12: {
                t.a(((x)object0), this.g);
                return H.a;
            }
            case 13: {
                t.a(((x)object0), this.g);
                return H.a;
            }
            case 14: {
                t.a(((x)object0), this.g);
                return H.a;
            }
            case 15: {
                t.a(((x)object0), this.g);
                return H.a;
            }
            case 16: {
                t.a(((x)object0), this.g);
                return H.a;
            }
            case 17: {
                t.a(((x)object0), this.g);
                return H.a;
            }
            case 18: {
                t.a(((x)object0), this.g);
                return H.a;
            }
            default: {
                t.a(((x)object0), this.g);
                return H.a;
            }
        }
    }
}

