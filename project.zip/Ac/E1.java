package Ac;

import E9.g;
import W.p;
import ie.H;
import kotlin.jvm.internal.q;
import we.k;
import x1.d;
import x1.e;
import x1.n;

public final class e1 implements k {
    public final int a;
    public final e b;

    public e1(e e0, int v) {
        this.a = v;
        this.b = e0;
        super();
    }

    @Override  // we.k
    public final Object invoke(Object object0) {
        switch(this.a) {
            case 0: {
                q.g(((d)object0), "$this$constrainAs");
                p.l(((d)object0).f, this.b.d, 0.0f, 6);
                g.v(((d)object0).e, ((d)object0).c.e, 0.0f, 6);
                g.v(((d)object0).g, ((d)object0).c.g, 0.0f, 6);
                ((d)object0).d(new n(null, "wrap"));
                return H.a;
            }
            case 1: {
                q.g(((d)object0), "$this$constrainAs");
                p.l(((d)object0).d, ((d)object0).c.d, 20.0f, 4);
                p.l(((d)object0).f, this.b.d, 0.0f, 6);
                g.v(((d)object0).e, ((d)object0).c.e, 0.0f, 6);
                g.v(((d)object0).g, ((d)object0).c.g, 0.0f, 6);
                ((d)object0).d(new n(null, "spread"));
                return H.a;
            }
            case 2: {
                q.g(((d)object0), "$this$constrainAs");
                g.v(((d)object0).e, this.b.g, 0.0f, 6);
                g.v(((d)object0).g, ((d)object0).c.g, 0.0f, 6);
                return H.a;
            }
            case 3: {
                q.g(((d)object0), "$this$constrainAs");
                g.v(((d)object0).e, this.b.g, 0.0f, 6);
                g.v(((d)object0).g, ((d)object0).c.g, 0.0f, 6);
                return H.a;
            }
            case 4: {
                q.g(((d)object0), "$this$constrainAs");
                g.v(((d)object0).e, this.b.g, 0.0f, 6);
                g.v(((d)object0).g, ((d)object0).c.g, 0.0f, 6);
                return H.a;
            }
            case 5: {
                q.g(((d)object0), "$this$constrainAs");
                p.l(((d)object0).d, ((d)object0).c.d, 0.0f, 6);
                p.l(((d)object0).f, ((d)object0).c.f, 0.0f, 6);
                g.v(((d)object0).g, this.b.e, -3.0f, 4);
                return H.a;
            }
            case 6: {
                q.g(((d)object0), "$this$constrainAs");
                p.l(((d)object0).d, ((d)object0).c.d, 0.0f, 6);
                p.l(((d)object0).f, ((d)object0).c.f, 0.0f, 6);
                g.v(((d)object0).g, this.b.g, 45.0f, 4);
                ((d)object0).d(new n(null, "wrap"));
                ((d)object0).c(new n(null, "wrap"));
                return H.a;
            }
            case 7: {
                q.g(((d)object0), "$this$constrainAs");
                g.v(((d)object0).e, this.b.e, 38.0f, 4);
                p.l(((d)object0).d, this.b.d, 0.0f, 6);
                p.l(((d)object0).f, this.b.f, 0.0f, 6);
                return H.a;
            }
            case 8: {
                q.g(((d)object0), "$this$constrainAs");
                d.b(((d)object0), this.b.f, ((d)object0).c.f, 3.0f, 0.0f, 0.0f, 40);
                g.v(((d)object0).e, ((d)object0).c.e, 12.5f, 4);
                ((d)object0).d(new n(null, "spread"));
                return H.a;
            }
            case 9: {
                q.g(((d)object0), "$this$constrainAs");
                p.l(((d)object0).d, ((d)object0).c.d, 0.0f, 6);
                p.l(((d)object0).f, ((d)object0).c.f, 0.0f, 6);
                g.v(((d)object0).g, this.b.g, 45.0f, 4);
                ((d)object0).d(new n(null, "wrap"));
                ((d)object0).c(new n(null, "wrap"));
                return H.a;
            }
            default: {
                q.g(((d)object0), "$this$constrainAs");
                p.l(((d)object0).d, ((d)object0).c.d, 0.0f, 6);
                p.l(((d)object0).f, ((d)object0).c.f, 0.0f, 6);
                g.v(((d)object0).e, this.b.g, 0.0f, 6);
                ((d)object0).d(new n(null, "spread"));
                ((d)object0).c(new n(null, "wrap"));
                return H.a;
            }
        }
    }
}

