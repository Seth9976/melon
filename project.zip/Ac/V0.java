package Ac;

public interface v0 {
}

