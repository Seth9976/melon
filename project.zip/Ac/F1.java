package Ac;

import N0.Z;
import ie.H;
import java.util.LinkedHashMap;
import java.util.List;
import kotlin.jvm.internal.r;
import we.k;
import x1.q;

public final class f1 extends r implements k {
    public final int f;
    public final q g;
    public final List h;
    public final LinkedHashMap i;

    public f1(q q0, List list0, LinkedHashMap linkedHashMap0, int v) {
        this.f = v;
        this.g = q0;
        this.h = list0;
        this.i = linkedHashMap0;
        super(1);
    }

    @Override  // we.k
    public final Object invoke(Object object0) {
        switch(this.f) {
            case 0: {
                this.g.e(((Z)object0), this.h, this.i);
                return H.a;
            }
            case 1: {
                this.g.e(((Z)object0), this.h, this.i);
                return H.a;
            }
            case 2: {
                this.g.e(((Z)object0), this.h, this.i);
                return H.a;
            }
            case 3: {
                this.g.e(((Z)object0), this.h, this.i);
                return H.a;
            }
            case 4: {
                this.g.e(((Z)object0), this.h, this.i);
                return H.a;
            }
            case 5: {
                this.g.e(((Z)object0), this.h, this.i);
                return H.a;
            }
            case 6: {
                this.g.e(((Z)object0), this.h, this.i);
                return H.a;
            }
            case 7: {
                this.g.e(((Z)object0), this.h, this.i);
                return H.a;
            }
            case 8: {
                this.g.e(((Z)object0), this.h, this.i);
                return H.a;
            }
            case 9: {
                this.g.e(((Z)object0), this.h, this.i);
                return H.a;
            }
            case 10: {
                this.g.e(((Z)object0), this.h, this.i);
                return H.a;
            }
            case 11: {
                this.g.e(((Z)object0), this.h, this.i);
                return H.a;
            }
            case 12: {
                this.g.e(((Z)object0), this.h, this.i);
                return H.a;
            }
            case 13: {
                this.g.e(((Z)object0), this.h, this.i);
                return H.a;
            }
            case 14: {
                this.g.e(((Z)object0), this.h, this.i);
                return H.a;
            }
            case 15: {
                this.g.e(((Z)object0), this.h, this.i);
                return H.a;
            }
            case 16: {
                this.g.e(((Z)object0), this.h, this.i);
                return H.a;
            }
            case 17: {
                this.g.e(((Z)object0), this.h, this.i);
                return H.a;
            }
            case 18: {
                this.g.e(((Z)object0), this.h, this.i);
                return H.a;
            }
            default: {
                this.g.e(((Z)object0), this.h, this.i);
                return H.a;
            }
        }
    }
}

