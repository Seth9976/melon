package ac;

public interface d {
}

