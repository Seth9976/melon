package Ac;

import androidx.compose.runtime.b0;
import ie.H;
import kotlin.jvm.internal.r;
import we.a;
import x1.m;

public final class h1 extends r implements a {
    public final int f;
    public final b0 g;
    public final m h;

    public h1(b0 b00, m m0, int v) {
        this.f = v;
        this.g = b00;
        this.h = m0;
        super(0);
    }

    @Override  // we.a
    public final Object invoke() {
        switch(this.f) {
            case 0: {
                Boolean boolean1 = Boolean.valueOf(!((Boolean)this.g.getValue()).booleanValue());
                this.g.setValue(boolean1);
                this.h.d = true;
                return H.a;
            }
            case 1: {
                Boolean boolean2 = Boolean.valueOf(!((Boolean)this.g.getValue()).booleanValue());
                this.g.setValue(boolean2);
                this.h.d = true;
                return H.a;
            }
            case 2: {
                Boolean boolean3 = Boolean.valueOf(!((Boolean)this.g.getValue()).booleanValue());
                this.g.setValue(boolean3);
                this.h.d = true;
                return H.a;
            }
            case 3: {
                Boolean boolean4 = Boolean.valueOf(!((Boolean)this.g.getValue()).booleanValue());
                this.g.setValue(boolean4);
                this.h.d = true;
                return H.a;
            }
            case 4: {
                Boolean boolean5 = Boolean.valueOf(!((Boolean)this.g.getValue()).booleanValue());
                this.g.setValue(boolean5);
                this.h.d = true;
                return H.a;
            }
            case 5: {
                Boolean boolean6 = Boolean.valueOf(!((Boolean)this.g.getValue()).booleanValue());
                this.g.setValue(boolean6);
                this.h.d = true;
                return H.a;
            }
            case 6: {
                Boolean boolean7 = Boolean.valueOf(!((Boolean)this.g.getValue()).booleanValue());
                this.g.setValue(boolean7);
                this.h.d = true;
                return H.a;
            }
            case 7: {
                Boolean boolean8 = Boolean.valueOf(!((Boolean)this.g.getValue()).booleanValue());
                this.g.setValue(boolean8);
                this.h.d = true;
                return H.a;
            }
            case 8: {
                Boolean boolean9 = Boolean.valueOf(!((Boolean)this.g.getValue()).booleanValue());
                this.g.setValue(boolean9);
                this.h.d = true;
                return H.a;
            }
            case 9: {
                Boolean boolean10 = Boolean.valueOf(!((Boolean)this.g.getValue()).booleanValue());
                this.g.setValue(boolean10);
                this.h.d = true;
                return H.a;
            }
            case 10: {
                Boolean boolean11 = Boolean.valueOf(!((Boolean)this.g.getValue()).booleanValue());
                this.g.setValue(boolean11);
                this.h.d = true;
                return H.a;
            }
            case 11: {
                Boolean boolean12 = Boolean.valueOf(!((Boolean)this.g.getValue()).booleanValue());
                this.g.setValue(boolean12);
                this.h.d = true;
                return H.a;
            }
            case 12: {
                Boolean boolean13 = Boolean.valueOf(!((Boolean)this.g.getValue()).booleanValue());
                this.g.setValue(boolean13);
                this.h.d = true;
                return H.a;
            }
            case 13: {
                Boolean boolean14 = Boolean.valueOf(!((Boolean)this.g.getValue()).booleanValue());
                this.g.setValue(boolean14);
                this.h.d = true;
                return H.a;
            }
            case 14: {
                Boolean boolean15 = Boolean.valueOf(!((Boolean)this.g.getValue()).booleanValue());
                this.g.setValue(boolean15);
                this.h.d = true;
                return H.a;
            }
            case 15: {
                Boolean boolean16 = Boolean.valueOf(!((Boolean)this.g.getValue()).booleanValue());
                this.g.setValue(boolean16);
                this.h.d = true;
                return H.a;
            }
            case 16: {
                Boolean boolean17 = Boolean.valueOf(!((Boolean)this.g.getValue()).booleanValue());
                this.g.setValue(boolean17);
                this.h.d = true;
                return H.a;
            }
            case 17: {
                Boolean boolean18 = Boolean.valueOf(!((Boolean)this.g.getValue()).booleanValue());
                this.g.setValue(boolean18);
                this.h.d = true;
                return H.a;
            }
            case 18: {
                Boolean boolean19 = Boolean.valueOf(!((Boolean)this.g.getValue()).booleanValue());
                this.g.setValue(boolean19);
                this.h.d = true;
                return H.a;
            }
            default: {
                Boolean boolean0 = Boolean.valueOf(!((Boolean)this.g.getValue()).booleanValue());
                this.g.setValue(boolean0);
                this.h.d = true;
                return H.a;
            }
        }
    }
}

