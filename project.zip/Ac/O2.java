package Ac;

import Ad.l;
import Bd.P;
import Bd.g;
import Cd.G;
import Cd.S;
import J8.t;
import Pc.e;
import com.iloen.melon.custom.title.TitleBar;
import com.melon.ui.I4;
import ie.H;
import kotlin.jvm.internal.n;
import kotlin.jvm.internal.q;
import we.k;

public final class o2 extends n implements k {
    public final int b;

    public o2(int v, Object object0, Class class0, String s, String s1, int v1, int v2) {
        this.b = v2;
        super(v, v1, class0, object0, s, s1);
    }

    @Override  // we.k
    public final Object invoke(Object object0) {
        H h0 = H.a;
        switch(this.b) {
            case 0: {
                q.g(((e)object0), "p0");
                ((v2)this.receiver).sendUserEvent(((e)object0));
                return h0;
            }
            case 1: {
                q.g(((e)object0), "p0");
                ((v2)this.receiver).sendUserEvent(((e)object0));
                return h0;
            }
            case 2: {
                q.g(((e)object0), "p0");
                ((v2)this.receiver).sendUserEvent(((e)object0));
                return h0;
            }
            case 3: {
                q.g(((e)object0), "p0");
                ((v2)this.receiver).sendUserEvent(((e)object0));
                return h0;
            }
            case 4: {
                boolean z = ((Boolean)object0).booleanValue();
                t t0 = (t)((v2)this.receiver).getBinding();
                if(t0 != null) {
                    ((TitleBar)t0.d.c).f(z);
                }
                return h0;
            }
            case 5: {
                q.g(((I4)object0), "p0");
                ((N2)this.receiver).sendUiEvent(((I4)object0));
                return h0;
            }
            case 6: {
                q.g(((e)object0), "p0");
                ((j3)this.receiver).sendUserEvent(((e)object0));
                return h0;
            }
            case 7: {
                q.g(((e)object0), "p0");
                ((j3)this.receiver).sendUserEvent(((e)object0));
                return h0;
            }
            case 8: {
                q.g(((e)object0), "p0");
                ((j3)this.receiver).sendUserEvent(((e)object0));
                return h0;
            }
            case 9: {
                q.g(((e)object0), "p0");
                ((j3)this.receiver).sendUserEvent(((e)object0));
                return h0;
            }
            case 10: {
                q.g(((I4)object0), "p0");
                ((L3)this.receiver).sendUiEvent(((I4)object0));
                return h0;
            }
            case 11: {
                q.g(((e)object0), "p0");
                ((h4)this.receiver).sendUserEvent(((e)object0));
                return h0;
            }
            case 12: {
                q.g(((e)object0), "p0");
                ((h4)this.receiver).sendUserEvent(((e)object0));
                return h0;
            }
            case 13: {
                q.g(((e)object0), "p0");
                ((h4)this.receiver).sendUserEvent(((e)object0));
                return h0;
            }
            case 14: {
                q.g(((e)object0), "p0");
                ((h4)this.receiver).sendUserEvent(((e)object0));
                return h0;
            }
            case 15: {
                q.g(((e)object0), "p0");
                ((h4)this.receiver).sendUserEvent(((e)object0));
                return h0;
            }
            case 16: {
                q.g(((e)object0), "p0");
                ((h4)this.receiver).sendUserEvent(((e)object0));
                return h0;
            }
            case 17: {
                q.g(((e)object0), "p0");
                ((h4)this.receiver).sendUserEvent(((e)object0));
                return h0;
            }
            case 18: {
                q.g(((e)object0), "p0");
                ((h4)this.receiver).sendUserEvent(((e)object0));
                return h0;
            }
            case 19: {
                q.g(((e)object0), "p0");
                ((h4)this.receiver).sendUserEvent(((e)object0));
                return h0;
            }
            case 20: {
                q.g(((e)object0), "p0");
                ((h4)this.receiver).sendUserEvent(((e)object0));
                return h0;
            }
            case 21: {
                q.g(((I4)object0), "p0");
                ((r4)this.receiver).sendUiEvent(((I4)object0));
                return h0;
            }
            case 22: {
                q.g(((e)object0), "p0");
                ((l)this.receiver).sendUserEvent(((e)object0));
                return h0;
            }
            case 23: {
                q.g(((e)object0), "p0");
                ((g)this.receiver).sendUserEvent(((e)object0));
                return h0;
            }
            case 24: {
                q.g(((I4)object0), "p0");
                ((P)this.receiver).sendUiEvent(((I4)object0));
                return h0;
            }
            case 25: {
                q.g(((I4)object0), "p0");
                ((P)this.receiver).sendUiEvent(((I4)object0));
                return h0;
            }
            case 26: {
                q.g(((e)object0), "p0");
                ((G)this.receiver).sendUserEvent(((e)object0));
                return h0;
            }
            case 27: {
                q.g(((e)object0), "p0");
                ((G)this.receiver).sendUserEvent(((e)object0));
                return h0;
            }
            case 28: {
                q.g(((e)object0), "p0");
                ((G)this.receiver).sendUserEvent(((e)object0));
                return h0;
            }
            default: {
                q.g(((I4)object0), "p0");
                ((S)this.receiver).sendUiEvent(((I4)object0));
                return h0;
            }
        }
    }
}

