package ae;

public interface a {
}

