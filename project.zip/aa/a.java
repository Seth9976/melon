package Aa;

import com.melon.data.service.SearchApi;
import kotlin.jvm.internal.q;

public final class a {
    public final SearchApi a;

    public a(SearchApi searchApi0) {
        q.g(searchApi0, "api");
        super();
        this.a = searchApi0;
    }
}

