package a5;

import U4.d;
import d5.q;
import kotlinx.coroutines.flow.Flow;

public interface e {
    Flow a(d arg1);

    boolean b(q arg1);

    boolean c(q arg1);
}

