package a5;

import kotlinx.coroutines.channels.ProducerScope;

public final class a {
    public final c a;
    public final ProducerScope b;

    public a(c c0, ProducerScope producerScope0) {
        this.a = c0;
        this.b = producerScope0;
    }
}

