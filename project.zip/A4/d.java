package a4;

public final class d {
    public final int a;
    public final int b;

    public d(int v, int v1) {
        this.a = v;
        this.b = v1;
    }
}

