package a4;

public final class a {
    public final int a;
    public final int[] b;
    public final int[] c;
    public final int[] d;

    public a(int v, int[] arr_v, int[] arr_v1, int[] arr_v2) {
        this.a = v;
        this.b = arr_v;
        this.c = arr_v1;
        this.d = arr_v2;
    }
}

