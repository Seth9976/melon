package a4;

import android.util.SparseArray;

public final class g {
    public final int a;
    public final int b;
    public final SparseArray c;
    public final SparseArray d;
    public final SparseArray e;
    public final SparseArray f;
    public final SparseArray g;
    public Object h;
    public Object i;

    public g(int v, int v1, int v2) {
        if(v2 != 1) {
            super();
            this.a = v;
            this.b = v1;
            this.c = new SparseArray();
            this.d = new SparseArray();
            this.e = new SparseArray();
            this.f = new SparseArray();
            this.g = new SparseArray();
            return;
        }
        super();
        this.a = v;
        this.b = v1;
        this.c = new SparseArray();
        this.d = new SparseArray();
        this.e = new SparseArray();
        this.f = new SparseArray();
        this.g = new SparseArray();
    }
}

