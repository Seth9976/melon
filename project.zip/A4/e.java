package a4;

import android.util.SparseArray;

public final class e {
    public final int a;
    public final boolean b;
    public final int c;
    public final int d;
    public final int e;
    public final int f;
    public final int g;
    public final int h;
    public final int i;
    public final SparseArray j;

    public e(int v, boolean z, int v1, int v2, int v3, int v4, int v5, int v6, int v7, SparseArray sparseArray0) {
        this.a = v;
        this.b = z;
        this.c = v1;
        this.d = v2;
        this.e = v3;
        this.f = v4;
        this.g = v5;
        this.h = v6;
        this.i = v7;
        this.j = sparseArray0;
    }
}

