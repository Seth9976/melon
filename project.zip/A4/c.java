package a4;

public final class c {
    public final int a;
    public final boolean b;
    public final byte[] c;
    public final byte[] d;

    public c(int v, boolean z, byte[] arr_b, byte[] arr_b1) {
        this.a = v;
        this.b = z;
        this.c = arr_b;
        this.d = arr_b1;
    }
}

