package a4;

public final class f {
    public final int a;
    public final int b;

    public f(int v, int v1) {
        this.a = v;
        this.b = v1;
    }
}

