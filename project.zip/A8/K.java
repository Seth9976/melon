package A8;

import kotlin.jvm.internal.q;
import pe.b;

public enum k {
    KAKAO_EMOTICON;

    public static final k[] b;

    static {
        k.b = arr_k;
        q.g(arr_k, "entries");
        new b(arr_k);
    }
}

