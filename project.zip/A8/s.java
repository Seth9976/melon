package A8;

import kotlin.jvm.internal.q;
import pe.b;

public enum s {
    LETTER,
    BYTE;

    public static final s[] c;

    static {
        s.c = arr_s;
        q.g(arr_s, "entries");
        new b(arr_s);
    }
}

