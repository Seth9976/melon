package A8;

public abstract class d {
    public static final int a;

    static {
    }
}

