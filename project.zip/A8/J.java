package A8;

import kotlin.jvm.internal.q;
import pe.b;

public enum j {
    KAKAO_TALK,
    KAKAO_ACCOUNT;

    public static final j[] c;

    static {
        j.c = arr_j;
        q.g(arr_j, "entries");
        new b(arr_j);
    }
}

