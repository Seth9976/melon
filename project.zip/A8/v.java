package A8;

import kotlin.jvm.internal.q;
import pe.b;

public enum v {
    BASIC,
    MIX_UP;

    public static final v[] c;

    static {
        v.c = arr_v;
        q.g(arr_v, "entries");
        new b(arr_v);
    }
}

