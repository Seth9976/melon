package A8;

import com.iloen.melon.MelonAppBase;
import com.iloen.melon.utils.color.ColorUtils;
import k8.t;

public abstract class i {
    public static int a;
    public static int b;
    public static int c;
    public static final int d;
    public static final int e;
    public static int f;
    public static int g;
    public static int h;
    public static int i;
    public static int j;
    public static int k;
    public static int l;
    public static int m;
    public static int n;
    public static int o;
    public static int p;
    public static int q;
    public static int r;

    static {
        MelonAppBase.Companion.getClass();
        i.a = ColorUtils.getColor(t.a().getContext(), 0x7F060189);  // color:hc_green500e
        i.b = ColorUtils.getColor(t.a().getContext(), 0x7F06018A);  // color:hc_green500s
        i.c = ColorUtils.getColor(t.a().getContext(), 0x7F06018C);  // color:hc_green502s
        i.d = ColorUtils.getColor(t.a().getContext(), 0x7F06018B);  // color:hc_green502e
        i.e = ColorUtils.getColor(t.a().getContext(), 0x7F060186);  // color:hc_gray600s
        i.f = ColorUtils.getColor(t.a().getContext(), 0x7F060185);  // color:hc_gray500s
        i.g = ColorUtils.getColor(t.a().getContext(), 0x7F060184);  // color:hc_gray400s
        i.h = ColorUtils.getColor(t.a().getContext(), 0x7F060183);  // color:hc_gray200s
        i.i = ColorUtils.getColor(t.a().getContext(), 0x7F060182);  // color:hc_gray100s
        i.j = ColorUtils.getColor(t.a().getContext(), 0x7F06018D);  // color:hc_white000s
        i.k = ColorUtils.getColor(t.a().getContext(), 0x7F060187);  // color:hc_gray920e
        i.l = ColorUtils.getColor(t.a().getContext(), 0x7F060188);  // color:hc_gray920e_10
        i.m = ColorUtils.getColor(t.a().getContext(), 0x7F060181);  // color:hc_gray001e
        i.n = ColorUtils.getColor(t.a().getContext(), 0x7F060191);  // color:hc_white500e
        i.o = ColorUtils.getColor(t.a().getContext(), 0x7F060190);  // color:hc_white400e
        i.p = ColorUtils.getColor(t.a().getContext(), 0x7F06018F);  // color:hc_white300e
        i.q = ColorUtils.getColor(t.a().getContext(), 0x7F06018E);  // color:hc_white160e
        i.r = ColorUtils.getColor(t.a().getContext(), 0x7F060180);  // color:hc_blue400s
    }
}

