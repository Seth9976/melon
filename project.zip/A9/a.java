package a9;

import androidx.fragment.app.I;

public interface a {
    void addFragment(I arg1);

    void removeFragment(I arg1);
}

