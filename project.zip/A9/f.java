package a9;

public interface f {
}

