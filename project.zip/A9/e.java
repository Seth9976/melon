package a9;

public interface e {
    void onStopScroll();

    void onUpdateParallaxHeader();

    void onUpdateScroll(int arg1);
}

