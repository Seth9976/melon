package a9;

import androidx.recyclerview.widget.RecyclerView;

public interface c {
    void onScrollStateChanged(RecyclerView arg1, int arg2);

    void onScrolled(RecyclerView arg1, int arg2);
}

