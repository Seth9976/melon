package a9;

public interface d {
    void onSelected(int arg1);
}

