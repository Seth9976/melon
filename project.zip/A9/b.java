package a9;

public interface b {
    int getFixedHeight();

    int getHeaderHeight();

    int getHeaderTranslationHeight();

    int getTranslationPosition();
}

