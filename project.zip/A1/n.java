package a1;

import e1.u;

public abstract class n {
    public static final long a;
    public static final m b;

    static {
        n.a = u.M(0x200000000L, 1.0f);
        n.b = new m(u.M(0x200000000L, 0.25f), u.M(0x200000000L, 0.25f));
    }
}

