package a1;

public abstract class w implements b {
    public abstract S a();
}

