package a1;

public final class q {
    @Override
    public final boolean equals(Object object0) {
        if(!(object0 instanceof q)) {
            return false;
        }
        ((q)object0).getClass();
        return true;
    }

    @Override
    public final int hashCode() {
        return 0;
    }

    @Override
    public final String toString() {
        return "EmojiSupportMatch.Default";
    }
}

