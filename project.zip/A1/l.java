package a1;

import kotlin.jvm.internal.q;
import pe.b;

public enum l {
    Paragraph,
    Span,
    VerbatimTts,
    Url,
    Link,
    Clickable,
    String;

    public static final l[] h;

    static {
        l.h = arr_l;
        q.g(arr_l, "entries");
        new b(arr_l);
    }
}

