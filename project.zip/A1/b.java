package a1;

public interface b {
}

