package a1;

public final class k {
    public final String a;
    public final String b;

    public k(String s, String s1) {
        this.a = s;
        this.b = s1;
    }
}

