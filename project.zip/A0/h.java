package a0;

public interface h {
    void O();
}

