package a0;

import androidx.compose.runtime.c1;

public abstract class l {
    public static final c1 a;
    public static final f b;
    public static final f c;

    static {
        l.a = new c1(k.f);  // 初始化器: Landroidx/compose/runtime/l0;-><init>(Lwe/a;)V
        l.b = new f(0.16f, 0.24f, 0.08f, 0.24f);
        l.c = new f(0.08f, 0.12f, 0.04f, 0.12f);
    }
}

