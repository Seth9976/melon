package a0;

import kotlin.jvm.internal.r;
import we.a;

public final class k extends r implements a {
    public static final k f;

    static {
        k.f = new k(0);  // 初始化器: Lkotlin/jvm/internal/r;-><init>(I)V
    }

    @Override  // we.a
    public final Object invoke() {
        return c.a;
    }
}

