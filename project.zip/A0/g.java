package a0;

import df.v;
import r1.c;
import x0.b;
import x0.e;

public abstract class g {
    public static final float a;

    static {
        g.a = 10.0f;
    }

    public static final float a(c c0, boolean z, long v) {
        float f = b.c(v.h(e.d(v), e.b(v)));
        return z ? c0.Y(g.a) + f / 2.0f : f / 2.0f;
    }
}

