package a0;

import G.C;
import G.x0;

public abstract class i {
    public static final x0 a;

    static {
        i.a = new x0(15, C.d, 2);
    }
}

