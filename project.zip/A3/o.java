package a3;

import b3.E;

public final class o {
    public final long a;
    public final long b;
    public final boolean c;
    public final E d;
    public final String e;
    public static final o f;

    static {
        o.f = new o(0x8000000000000001L, 0x8000000000000001L, false, E.g, "UNKNOWN_CONTENT_ID");
    }

    public o(long v, long v1, boolean z, E e0, String s) {
        this.a = v;
        this.b = v1;
        this.c = z;
        this.d = e0;
        this.e = s;
    }
}

