package a3;

import com.google.android.gms.common.api.ResultCallback;

public final class l {
    public Object a;
    public ResultCallback b;

    public l(Object object0) {
        this.a = object0;
    }
}

