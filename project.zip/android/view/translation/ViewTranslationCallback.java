package android.view.translation;

public interface ViewTranslationCallback {
    static {
        throw new NoClassDefFoundError();
    }
}

