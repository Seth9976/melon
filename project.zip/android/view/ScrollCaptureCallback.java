package android.view;

public interface ScrollCaptureCallback {
    static {
        throw new NoClassDefFoundError();
    }
}

