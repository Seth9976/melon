package android.net.http;

import javax.net.ssl.SSLSocket;

public class CertificateChainValidator {
    public CertificateChainValidator() {
        throw new RuntimeException("Stub!");
    }

    public SslError doHandshakeAndValidateServerCertificates(HttpsConnection httpsConnection0, SSLSocket sSLSocket0, String s) {
        throw new RuntimeException("Stub!");
    }

    public static CertificateChainValidator getInstance() {
        throw new RuntimeException("Stub!");
    }

    public static void handleTrustStorageUpdate() {
        throw new RuntimeException("Stub!");
    }

    public static SslError verifyServerCertificates(byte[][] arr2_b, String s, String s1) {
        throw new RuntimeException("Stub!");
    }
}

