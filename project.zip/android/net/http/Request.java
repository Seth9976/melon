package android.net.http;

class Request {
    public Request() {
        throw new RuntimeException("Stub!");
    }

    public void handleSslErrorResponse(boolean z) {
        throw new RuntimeException("Stub!");
    }

    @Override
    public String toString() {
        throw new RuntimeException("Stub!");
    }
}

