package android.net.compatibility;

public class WebAddress {
    public WebAddress(String s) {
        throw new RuntimeException("Stub!");
    }

    public String getAuthInfo() {
        throw new RuntimeException("Stub!");
    }

    public String getHost() {
        throw new RuntimeException("Stub!");
    }

    public String getPath() {
        throw new RuntimeException("Stub!");
    }

    public int getPort() {
        throw new RuntimeException("Stub!");
    }

    public String getScheme() {
        throw new RuntimeException("Stub!");
    }

    public void setAuthInfo(String s) {
        throw new RuntimeException("Stub!");
    }

    public void setHost(String s) {
        throw new RuntimeException("Stub!");
    }

    public void setPath(String s) {
        throw new RuntimeException("Stub!");
    }

    public void setPort(int v) {
        throw new RuntimeException("Stub!");
    }

    public void setScheme(String s) {
        throw new RuntimeException("Stub!");
    }

    @Override
    public String toString() {
        throw new RuntimeException("Stub!");
    }
}

