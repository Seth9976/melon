package android.graphics;

public interface ImageDecoder.OnPartialImageListener {
    static {
        throw new NoClassDefFoundError();
    }
}

