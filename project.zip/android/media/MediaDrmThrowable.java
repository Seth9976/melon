package android.media;

public interface MediaDrmThrowable {
    static {
        throw new NoClassDefFoundError();
    }
}

