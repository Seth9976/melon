package android.media;

public class MediaRouter2.ControllerCallback {
    static {
        throw new NoClassDefFoundError();
    }
}

