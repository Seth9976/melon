package android.media;

public interface Spatializer.OnSpatializerStateChangedListener {
    static {
        throw new NoClassDefFoundError();
    }
}

