package android.media;

import android.app.Service;

public class MediaRoute2ProviderService extends Service {
    static {
        throw new NoClassDefFoundError();
    }
}

