package android.media;

public interface LoudnessCodecController.OnLoudnessCodecUpdateListener {
    static {
        throw new NoClassDefFoundError();
    }
}

