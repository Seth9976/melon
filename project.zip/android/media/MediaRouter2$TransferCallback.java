package android.media;

public class MediaRouter2.TransferCallback {
    static {
        throw new NoClassDefFoundError();
    }
}

