package android.media;

public class MediaRouter2.RouteCallback {
    static {
        throw new NoClassDefFoundError();
    }
}

