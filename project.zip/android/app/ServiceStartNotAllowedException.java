package android.app;

public class ServiceStartNotAllowedException extends IllegalStateException {
    static {
        throw new NoClassDefFoundError();
    }
}

