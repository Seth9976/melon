package android.telephony;

public interface TelephonyCallback.DisplayInfoListener {
    static {
        throw new NoClassDefFoundError();
    }
}

