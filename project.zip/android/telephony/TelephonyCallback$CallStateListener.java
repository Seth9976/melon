package android.telephony;

public interface TelephonyCallback.CallStateListener {
    static {
        throw new NoClassDefFoundError();
    }
}

