package android.adservices.topics;

public final class GetTopicsRequest {
    public static final class Builder {
        public Builder() {
            throw new RuntimeException("Stub!");
        }

        public GetTopicsRequest build() {
            throw new RuntimeException("Stub!");
        }

        public Builder setAdsSdkName(String s) {
            throw new RuntimeException("Stub!");
        }

        public Builder setShouldRecordObservation(boolean z) {
            throw new RuntimeException("Stub!");
        }
    }

    public GetTopicsRequest() {
        throw new RuntimeException("Stub!");
    }

    public String getAdsSdkName() {
        throw new RuntimeException("Stub!");
    }

    public boolean shouldRecordObservation() {
        throw new RuntimeException("Stub!");
    }
}

