package android.adservices.topics;

import android.content.Context;
import android.os.OutcomeReceiver;
import java.util.concurrent.Executor;

public final class TopicsManager {
    public TopicsManager() {
        throw new RuntimeException("Stub!");
    }

    public static TopicsManager get(Context context0) {
        throw new RuntimeException("Stub!");
    }

    public void getTopics(GetTopicsRequest getTopicsRequest0, Executor executor0, OutcomeReceiver outcomeReceiver0) {
        throw new RuntimeException("Stub!");
    }
}

