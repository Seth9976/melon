package android.adservices.topics;

import java.util.List;

public final class GetTopicsResponse {
    public static final class Builder {
        public Builder(List list0) {
            throw new RuntimeException("Stub!");
        }

        public GetTopicsResponse build() {
            throw new RuntimeException("Stub!");
        }
    }

    public GetTopicsResponse() {
        throw new RuntimeException("Stub!");
    }

    @Override
    public boolean equals(Object object0) {
        throw new RuntimeException("Stub!");
    }

    public List getTopics() {
        throw new RuntimeException("Stub!");
    }

    @Override
    public int hashCode() {
        throw new RuntimeException("Stub!");
    }
}

