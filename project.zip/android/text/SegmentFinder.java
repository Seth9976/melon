package android.text;

public class SegmentFinder {
    static {
        throw new NoClassDefFoundError();
    }
}

