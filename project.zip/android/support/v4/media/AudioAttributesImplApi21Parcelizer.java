package android.support.v4.media;

import P4.b;
import androidx.media.AudioAttributesImplApi21;

public final class AudioAttributesImplApi21Parcelizer extends androidx.media.AudioAttributesImplApi21Parcelizer {
    @Override  // androidx.media.AudioAttributesImplApi21Parcelizer
    public static AudioAttributesImplApi21 read(b b0) {
        return androidx.media.AudioAttributesImplApi21Parcelizer.read(b0);
    }

    @Override  // androidx.media.AudioAttributesImplApi21Parcelizer
    public static void write(AudioAttributesImplApi21 audioAttributesImplApi210, b b0) {
        androidx.media.AudioAttributesImplApi21Parcelizer.write(audioAttributesImplApi210, b0);
    }
}

